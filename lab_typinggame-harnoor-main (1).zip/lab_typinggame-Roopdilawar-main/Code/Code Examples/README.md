To run:
   - Open displayDemo.s inside of rars
   - Assemble the program
   - Open Tools > Keyboard and Display MMIO Simulator
   - Click the "Connect to Program" button in the Keyboard and Display MMIO Simulator
   - Run the program