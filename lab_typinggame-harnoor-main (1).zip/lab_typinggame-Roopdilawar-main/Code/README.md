Lab Typing_Game

Code: 
typing.s -> This is the framework for you to write your code, write your typing, random and handler functions 
common.s -> RISC-V code that takes in a text file and parses the lines into an array, another array is created that contains pointers to the beginning of every phrase. iTrapData is created and the address is placed into the utvec register
Code Examples -> Contains code demonstrating the Display Screen, displayDemo.s
